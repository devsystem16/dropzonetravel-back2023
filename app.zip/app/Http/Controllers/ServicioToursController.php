<?php

namespace App\Http\Controllers;

use App\Models\ServicioTours;
use Illuminate\Http\Request;

class ServicioToursController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ServicioTours  $servicioTours
     * @return \Illuminate\Http\Response
     */
    public function show(ServicioTours $servicioTours)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ServicioTours  $servicioTours
     * @return \Illuminate\Http\Response
     */
    public function edit(ServicioTours $servicioTours)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ServicioTours  $servicioTours
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ServicioTours $servicioTours)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ServicioTours  $servicioTours
     * @return \Illuminate\Http\Response
     */
    public function destroy(ServicioTours $servicioTours)
    {
        //
    }
}
